import datetime

from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _

class CreateEmployeeForm(forms.Form):
    emplid = forms.CharField(max_length=6,help_text="Enter new employee's ID")
    name=forms.CharField(help_text="Enter new employee's Name")
    date_of_joining=forms.DateField()
    is_active=forms.BooleanField()

    def clean_emplid(self):
        emplid = self.cleaned_data['emplid']
		# Check emplid is in the allowed range (4 to 6).
        if len(emplid) > 6 or len(emplid) < 4:
            raise ValidationError(_('Invalid emplid - should be in range 4 to 6'))
        return emplid

    def clean_name(self):		
        name = self.cleaned_data['name']
        return name
		
    def clean_date_of_joining(self):		
        date_of_joining = self.cleaned_data['date_of_joining']
        return date_of_joining
		
    def clean_is_active(self):		
        is_active = self.cleaned_data['is_active']
        return is_active
    data=[emplid,name,date_of_joining,is_active]
		
class CreateImageForm(forms.Form):
    image=forms.FileField()
    image_name=forms.CharField(max_length=50)

    def clean_image_name(self):
        image_name = self.cleaned_data['image_name']
		# Check emplid is in the allowed range (4 to 6).
        if len(image_name) < 4:
            raise ValidationError(_('Invalid image_name - should be greater than 4 '))
        return image_name

    
    data=[image,image_name]
        
        
        

       
