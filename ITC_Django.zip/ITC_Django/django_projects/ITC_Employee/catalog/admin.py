from django.contrib import admin

from catalog.models import Employee,Designation,Salary,Employee_image

admin.site.register(Employee_image)
#@admin.register(Employee)
#class EmployeeAdmin(admin.ModelAdmin):
 #   list_display = ('emplid', 'name', 'date_of_joining','is_active')

# Define the admin class
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('emplid', 'name', 'date_of_joining','is_active')
# Register the admin class with the associated model
admin.site.register(Employee, EmployeeAdmin)

@admin.register(Designation)
class DesignationAdmin(admin.ModelAdmin):
    list_display = ('emplid', 'title', 'is_current_title')
#admin.site.register(Designation)



#admin.site.register(Salary)
@admin.register(Salary)
class SalaryAdmin(admin.ModelAdmin):
	list_display = ('emplid','salary','currency','is_current_salary')


