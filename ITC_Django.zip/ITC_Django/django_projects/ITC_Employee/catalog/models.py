from django.db import models

# Create your models here.

class Employee(models.Model):
	"""Model representing Employee"""
	emplid=models.CharField(max_length=6,primary_key=True)
	name=models.CharField(max_length=40)
	date_of_joining=models.DateField(blank=True)
	is_active=models.BooleanField()
	
	def __str__(self):
		"""String for representing the Model object."""
		return self.emplid
	
	
class Designation(models.Model):
	"""Model representing Designation of Employee"""
	emplid = models.ForeignKey('Employee', on_delete=models.SET_NULL, null=True)
	title=models.CharField(max_length=40)
	is_current_title=models.BooleanField()
	def __str__(self):
		"""String for representing the Model object."""
		return self.title
	


class Salary(models.Model):
	"""Model representing Employee Salary"""
	emplid=models.ForeignKey('Employee',on_delete=models.SET_NULL,null=True)
	salary=models.IntegerField()
	currency=models.CharField(max_length=5)
	is_current_salary=models.BooleanField()
	def __str__(self):
		"""String for representing the Model object."""
		return self.currency
	
	

class Employee_image(models.Model):
	"""Model representing Employee Image"""
	image=models.FileField(null=True,blank=True)
	image_name=models.CharField(max_length=50)
	def __str__(self):
		"""String for representing the Model object."""
		return self.image_name
