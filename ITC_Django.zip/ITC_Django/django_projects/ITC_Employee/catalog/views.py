from django.shortcuts import render

import datetime

from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse

from catalog.forms import CreateEmployeeForm,CreateImageForm

from catalog.models import Employee,Employee_image


def create_employee_form(request):
    #employee_instance = get_object_or_404(BookInstance, pk=pk)
    #employee=get_object_or_404(Employee)
    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = CreateEmployeeForm(request.POST)
        employee=Employee()

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            employee.emplid = form.cleaned_data['emplid']
            employee.name = form.cleaned_data['name']
            employee.date_of_joining = form.cleaned_data['date_of_joining']
            employee.is_active = form.cleaned_data['is_active']
            employee.save()

            # redirect to a new URL:
            return HttpResponseRedirect('/admin')

    # If this is a GET (or any other method) create the default form.
    else:
        
        form = CreateEmployeeForm()

    context = {
        'form': form,
        #'emplid': Employee.emplid,
		#'name': name,
		#'date_of_joining' : date_of_joining,
		#'is_active' : is_active,				
    }

    return render(request, 'catalog/add_new_employee.html', context)

	
	
from django.core.files.storage import FileSystemStorage	
	
def create_image_form(request):
   
    if request.method == 'POST':

        
		
		# Create a form instance and populate it with data from the request (binding):
        form = CreateImageForm(request.POST)
        employee_image=Employee_image()
		
        if form.is_valid():
            employee_image.image = form.cleaned_data['image']
            employee_image.image_name = form.cleaned_data['image_name']
            employee_image.save()
            print("cleaned data sumit")
        myfile = request.FILES['image']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        employee_image.save()   
        return render(request, 'catalog/add_employee_image.html', {'uploaded_file_url':uploaded_file_url})
        
    # If this is a GET (or any other method) create the default form.
    else:
        
        form = CreateImageForm()

    context = {
        'form': form,
        #'emplid': Employee.emplid,
		#'name': name,
		#'date_of_joining' : date_of_joining,
		#'is_active' : is_active,				
    }

    return render(request, 'catalog/add_employee_image.html', context)
	
