from django.apps import AppConfig


class TickTokAppConfig(AppConfig):
    name = 'Tick_tok_app'
